"""Logcat capture and lightweight failure classification."""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path

from .device import adb

ERROR_PATTERNS = {
    "fatal_exception": re.compile(r"FATAL EXCEPTION", re.IGNORECASE),
    "anr": re.compile(r"ANR in |Application Not Responding", re.IGNORECASE),
    "native_crash": re.compile(r"Fatal signal \d+|tombstoned|crash_dump", re.IGNORECASE),
    "android_runtime": re.compile(r"AndroidRuntime", re.IGNORECASE),
}


def classificar_logcat(texto: str) -> dict:
    lines = texto.splitlines()
    matches = {name: [line for line in lines if pattern.search(line)]
               for name, pattern in ERROR_PATTERNS.items()}
    return {
        "line_count": len(lines),
        "error_categories": {name: len(items) for name, items in matches.items() if items},
        "interesting_lines": [line for items in matches.values() for line in items][-100:],
    }


def coletar_logcat(destino: str | Path, serial: str, buffer: str = "main") -> Path:
    """Capture a Logcat buffer from a specific device into a UTF-8 text file."""
    content = adb(["logcat", "-d", "-b", buffer, "-v", "threadtime"], serial=serial, timeout=60)
    path = Path(destino)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def nome_logcat(prefix: str = "logcat") -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_prefix = re.sub(r"[^A-Za-z0-9_.-]+", "_", prefix)
    return f"{safe_prefix}_{stamp}.txt"
