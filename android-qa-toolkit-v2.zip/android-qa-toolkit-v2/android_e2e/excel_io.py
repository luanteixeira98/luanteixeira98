"""Read test cases and write results to Excel using openpyxl."""
from __future__ import annotations

from openpyxl import Workbook, load_workbook

COLUNAS_RESULTADO = ["ID", "Descrição", "Pacote", "Status", "versionName", "versionCode",
                     "targetSdk", "firstInstallTime", "lastUpdateTime", "installer",
                     "Print 1", "Print 2", "Observação", "Executado em", "Serial", "Logcat"]


def gerar_modelo(caminho):
    wb = Workbook()
    ws = wb.active
    ws.title = "Casos"
    ws.append(["ID", "Descrição", "Pacote", "Rótulo esperado", "Versão mínima"])
    ws.append(["TC001", "Android Settings package installed", "com.android.settings", "", ""])
    ws.append(["TC002", "Client app installed and up to date", "com.example.client", "", "2.0.0"])
    wb.save(caminho)


def ler_casos(caminho):
    wb = load_workbook(caminho, data_only=True)
    if "Casos" not in wb.sheetnames:
        raise ValueError("Workbook must contain a sheet named 'Casos'.")
    ws = wb["Casos"]
    cabecalho = [str(cell.value).strip() if cell.value else "" for cell in ws[1]]
    required = {"ID", "Descrição", "Pacote"}
    missing = required - set(cabecalho)
    if missing:
        raise ValueError(f"Missing required Excel columns: {', '.join(sorted(missing))}")
    casos = []
    for linha in ws.iter_rows(min_row=2, values_only=True):
        if not any(linha):
            continue
        reg = dict(zip(cabecalho, linha))
        pacote = str(reg.get("Pacote") or "").strip()
        caso_id = str(reg.get("ID") or "").strip()
        if not pacote or not caso_id:
            raise ValueError("Each non-empty test row must include ID and Pacote.")
        casos.append({
            "id": caso_id,
            "descricao": reg.get("Descrição") or "",
            "pacote": pacote,
            "rotulo": reg.get("Rótulo esperado") or None,
            "versao_minima": str(reg["Versão mínima"]) if reg.get("Versão mínima") else None,
        })
    return casos


def salvar_resultados(caminho, resultados):
    wb = Workbook()
    ws = wb.active
    ws.title = "Resultados"
    ws.append(COLUNAS_RESULTADO)
    for result in resultados:
        props = result.get("props") or {}
        ws.append([
            result["id"], result["descricao"], result["pacote"], result["status"],
            props.get("versionName"), props.get("versionCode"), props.get("targetSdk"),
            props.get("firstInstallTime"), props.get("lastUpdateTime"), props.get("installer"),
            result.get("print1"), result.get("print2"), result.get("obs"), result.get("quando"),
            result.get("serial"), result.get("logcat"),
        ])
        row_number = ws.max_row
        for column in (11, 12, 16):
            cell = ws.cell(row=row_number, column=column)
            if cell.value:
                cell.hyperlink = str(cell.value)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    wb.save(caminho)
