"""Manufacturer-neutral Appium session factory for Android devices."""
from __future__ import annotations

import os
from urllib.parse import urlparse

from dotenv import load_dotenv

from .device import selecionar_dispositivo

load_dotenv()


def appium_server_url() -> str:
    return os.getenv("APPIUM_SERVER_URL", "http://127.0.0.1:4723").rstrip("/")


def verificar_servidor_appium(url: str | None = None, timeout: float = 1.0) -> bool:
    """Check whether the Appium TCP endpoint accepts connections."""
    import socket
    parsed = urlparse(url or appium_server_url())
    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def criar_driver(serial: str | None = None, *, app_package: str | None = None,
                 app_activity: str | None = None, server_url: str | None = None):
    """Create an Appium session explicitly bound to one online ADB serial.

    App package/activity are optional, allowing generic device-level smoke tests.
    """
    from appium import webdriver
    from appium.options.android import UiAutomator2Options

    device_serial = selecionar_dispositivo(serial or os.getenv("ANDROID_UDID") or None)
    options = UiAutomator2Options()
    options.platform_name = "Android"
    options.automation_name = "UiAutomator2"
    options.device_name = device_serial
    options.udid = device_serial
    options.new_command_timeout = 180
    options.no_reset = True

    package = app_package or os.getenv("APP_PACKAGE")
    activity = app_activity or os.getenv("APP_ACTIVITY")
    if package:
        options.app_package = package
    if activity:
        options.app_activity = activity

    return webdriver.Remote(server_url or appium_server_url(), options=options)
