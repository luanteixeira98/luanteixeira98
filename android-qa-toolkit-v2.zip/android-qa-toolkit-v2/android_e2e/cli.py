"""Convenience commands for the Android QA Toolkit."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .device import AdbError, listar_dispositivos, resumo_dispositivo
from .logs import classificar_logcat, coletar_logcat


def main(argv=None):
    parser = argparse.ArgumentParser(description="Android QA Toolkit utilities")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("devices", help="List connected devices and their state")
    info = sub.add_parser("info", help="Print detailed information about an Android device")
    info.add_argument("--serial", required=True)
    logs = sub.add_parser("logcat", help="Collect Logcat and create a small error summary")
    logs.add_argument("--serial", required=True)
    logs.add_argument("--buffer", default="main")
    logs.add_argument("--out", default="reports/logcat.txt")
    args = parser.parse_args(argv)
    try:
        if args.command == "devices":
            for device in listar_dispositivos():
                print(f"{device.state:12} {device.serial:28} {device.model or ''}")
        elif args.command == "info":
            print(json.dumps(resumo_dispositivo(args.serial), indent=2, ensure_ascii=False))
        elif args.command == "logcat":
            path = coletar_logcat(args.out, args.serial, args.buffer)
            summary = classificar_logcat(path.read_text(encoding="utf-8", errors="replace"))
            summary_path = Path(str(path) + ".summary.json")
            summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
            print(f"Logcat: {path}\nSummary: {summary_path}\nDetected categories: {summary['error_categories']}")
        return 0
    except AdbError as exc:
        print(f"Device error: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
