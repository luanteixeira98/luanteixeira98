"""Device discovery and low-level Android operations through ADB.

No manufacturer-specific behavior is assumed. ADB serials (UDIDs) are used
whenever a command targets a particular device.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path


class AdbError(RuntimeError):
    """Raised when ADB is unavailable, times out, or returns an error."""


@dataclass(frozen=True)
class AdbDevice:
    serial: str
    state: str
    product: str | None = None
    model: str | None = None
    device: str | None = None
    transport_id: str | None = None

    @property
    def online(self) -> bool:
        return self.state == "device"


def _decode(value: bytes | str) -> str:
    return value if isinstance(value, str) else value.decode("utf-8", errors="replace")


def adb(args, serial=None, binario=False, timeout=30):
    """Run ``adb [-s SERIAL] ...`` and return stdout as text or bytes."""
    command = ["adb"] + (["-s", str(serial)] if serial else []) + [str(arg) for arg in args]
    if shutil.which("adb") is None:
        raise AdbError("ADB was not found. Install Android SDK Platform-Tools and add adb to PATH.")
    try:
        result = subprocess.run(command, capture_output=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise AdbError(f"ADB command timed out after {timeout}s: {' '.join(command)}") from exc
    except OSError as exc:
        raise AdbError(f"Could not execute ADB: {exc}") from exc

    if result.returncode != 0:
        message = _decode(result.stderr).strip() or _decode(result.stdout).strip()
        raise AdbError(message or f"ADB failed with exit code {result.returncode}: {' '.join(command)}")
    return result.stdout if binario else _decode(result.stdout)


def parse_devices_output(output: str) -> list[AdbDevice]:
    """Parse ``adb devices -l`` output, including offline/unauthorized states."""
    devices: list[AdbDevice] = []
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("List of devices") or line.startswith("* daemon"):
            continue
        parts = line.split()
        if len(parts) < 2 or parts[0] == "attached":
            continue
        attrs: dict[str, str] = {}
        for item in parts[2:]:
            if ":" in item:
                key, value = item.split(":", 1)
                attrs[key] = value
        devices.append(
            AdbDevice(
                serial=parts[0],
                state=parts[1],
                product=attrs.get("product"),
                model=attrs.get("model"),
                device=attrs.get("device"),
                transport_id=attrs.get("transport_id"),
            )
        )
    return devices


def listar_dispositivos() -> list[AdbDevice]:
    """Return every ADB device, including offline and unauthorized entries."""
    return parse_devices_output(adb(["devices", "-l"]))


def selecionar_dispositivo(serial: str | None = None) -> str:
    """Resolve a safe device serial; never silently choose among multiple devices."""
    devices = listar_dispositivos()
    if serial:
        match = next((item for item in devices if item.serial == serial), None)
        if match is None:
            known = ", ".join(item.serial for item in devices) or "none"
            raise AdbError(f"Device '{serial}' was not found. ADB devices: {known}")
        if not match.online:
            raise AdbError(f"Device '{serial}' is not ready (ADB state: {match.state}).")
        return match.serial

    online = [item for item in devices if item.online]
    if not online:
        states = ", ".join(f"{item.serial}={item.state}" for item in devices)
        detail = f" Detected states: {states}." if states else " No devices were detected."
        raise AdbError("No online Android device. Enable USB/Wireless debugging and accept the RSA prompt." + detail)
    if len(online) > 1:
        choices = ", ".join(item.serial for item in online)
        raise AdbError(f"More than one Android device is online ({choices}). Select one with --serial/--android-udid.")
    return online[0].serial


def _parse_getprop(output: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in output.splitlines():
        match = re.match(r"\[(.*?)\]: \[(.*)\]$", line.strip())
        if match:
            result[match.group(1)] = match.group(2)
    return result


def resumo_dispositivo(serial: str) -> dict[str, str | None]:
    """Collect a useful, manufacturer-neutral device inventory."""
    props = _parse_getprop(adb(["shell", "getprop"], serial=serial))
    def optional(command: list[str]) -> str | None:
        try:
            value = adb(command, serial=serial).strip()
            return value or None
        except AdbError:
            return None

    wm_size = optional(["shell", "wm", "size"])
    wm_density = optional(["shell", "wm", "density"])
    battery = optional(["shell", "dumpsys", "battery"])
    battery_level = None
    if battery:
        match = re.search(r"(?m)^\s*level:\s*(\d+)", battery)
        battery_level = match.group(1) if match else None

    return {
        "serial": serial,
        "manufacturer": props.get("ro.product.manufacturer"),
        "brand": props.get("ro.product.brand"),
        "model": props.get("ro.product.model"),
        "device": props.get("ro.product.device"),
        "product": props.get("ro.product.name"),
        "android_version": props.get("ro.build.version.release"),
        "api_level": props.get("ro.build.version.sdk"),
        "security_patch": props.get("ro.build.version.security_patch"),
        "build_id": props.get("ro.build.id"),
        "build_fingerprint": props.get("ro.build.fingerprint"),
        "cpu_abi_list": props.get("ro.product.cpu.abilist"),
        "screen_size": wm_size,
        "screen_density": wm_density,
        "battery_level_percent": battery_level,
    }


def pacote_instalado(pacote, serial=None):
    saida = adb(["shell", "pm", "list", "packages", pacote], serial)
    return f"package:{pacote}" in saida.splitlines()


def abrir_info_do_app(pacote, serial=None):
    adb(["shell", "am", "start", "-a", "android.settings.APPLICATION_DETAILS_SETTINGS",
         "-d", f"package:{pacote}"], serial)


def tamanho_tela(serial=None):
    saida = adb(["shell", "wm", "size"], serial)
    matches = re.findall(r"(\d+)x(\d+)", saida)
    if not matches:
        raise AdbError(f"Could not determine screen size from ADB output: {saida!r}")
    largura, altura = matches[-1]
    return int(largura), int(altura)


def rolar_para_baixo(serial=None):
    largura, altura = tamanho_tela(serial)
    adb(["shell", "input", "swipe", str(largura // 2), str(int(altura * 0.8)),
         str(largura // 2), str(int(altura * 0.25)), "300"], serial)


def screenshot_adb(destino, serial=None):
    path = Path(destino)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(adb(["exec-out", "screencap", "-p"], serial, binario=True))


def parse_dumpsys(texto):
    def achar(padrao):
        match = re.search(padrao, texto, re.MULTILINE)
        return match.group(1).strip() if match else None
    return {
        "versionName": achar(r"versionName=(\S+)"),
        "versionCode": achar(r"versionCode=(\d+)"),
        "targetSdk": achar(r"targetSdk=(\d+)"),
        "firstInstallTime": achar(r"firstInstallTime=(.+)"),
        "lastUpdateTime": achar(r"lastUpdateTime=(.+)"),
        "installer": achar(r"installerPackageName=(\S+)"),
    }


def propriedades_do_app(pacote, serial=None):
    return parse_dumpsys(adb(["shell", "dumpsys", "package", pacote], serial))


def main(argv=None):
    parser = argparse.ArgumentParser(description="Discover and inspect connected Android devices.")
    parser.add_argument("--serial", help="Inspect one specific ADB serial.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    args = parser.parse_args(argv)
    try:
        devices = listar_dispositivos()
        if args.serial:
            serials = [selecionar_dispositivo(args.serial)]
        else:
            serials = [item.serial for item in devices if item.online]
        payload = []
        for item in devices:
            row = asdict(item)
            if item.serial in serials:
                row["details"] = resumo_dispositivo(item.serial)
            payload.append(row)
        if args.json:
            print(json.dumps(payload, indent=2, ensure_ascii=False))
        else:
            if not payload:
                print("No Android devices detected. Run `adb devices -l` to troubleshoot.")
            for row in payload:
                print(f"[{row['state']}] {row['serial']}  {row.get('model') or ''}")
                for key, value in (row.get("details") or {}).items():
                    print(f"  {key}: {value}")
        return 0
    except AdbError as exc:
        parser.exit(2, f"Device discovery error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
