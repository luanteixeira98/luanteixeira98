"""Excel-driven Android E2E checks using ADB, with optional Appium screenshots."""
from __future__ import annotations

import argparse
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

from . import device as d
from .appium import criar_driver
from .excel_io import gerar_modelo, ler_casos, salvar_resultados
from .logs import coletar_logcat, nome_logcat


def versao_em_tupla(texto):
    numeros = []
    for pedaco in str(texto).replace("-", ".").split("."):
        if pedaco.isdigit():
            numeros.append(int(pedaco))
        else:
            break
    return tuple(numeros)


def versao_ok(atual, minima):
    return versao_em_tupla(atual) >= versao_em_tupla(minima)


def esperar_tela_configuracoes(driver, tempo=6):
    if driver is None:
        time.sleep(1.5)
        return
    fim = time.time() + tempo
    while time.time() < fim:
        if "settings" in (driver.current_package or "").lower():
            return
        time.sleep(0.3)
    raise TimeoutError("Android Settings did not become the foreground package in time.")


def capturar(destino, driver, serial):
    Path(destino).parent.mkdir(parents=True, exist_ok=True)
    if driver is not None:
        if not driver.get_screenshot_as_file(str(destino)):
            raise RuntimeError(f"Appium could not save screenshot: {destino}")
    else:
        d.screenshot_adb(destino, serial)


def executar_caso(caso, pasta_prints, serial=None, driver=None):
    resultado = {
        "id": caso["id"], "descricao": caso["descricao"], "pacote": caso["pacote"],
        "status": "ERROR", "props": {}, "print1": None, "print2": None,
        "obs": "", "quando": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "serial": serial, "logcat": None,
    }
    try:
        if not d.pacote_instalado(caso["pacote"], serial):
            resultado.update(status="FAIL", obs="app não está instalado")
            return resultado

        d.abrir_info_do_app(caso["pacote"], serial)
        esperar_tela_configuracoes(driver)
        pasta = Path(pasta_prints)
        pasta.mkdir(parents=True, exist_ok=True)
        p1 = pasta / f"{caso['id']}_1.png"
        capturar(p1, driver, serial)
        resultado["print1"] = str(p1)

        d.rolar_para_baixo(serial)
        time.sleep(0.5)
        p2 = pasta / f"{caso['id']}_2.png"
        capturar(p2, driver, serial)
        resultado["print2"] = str(p2)

        resultado["props"] = d.propriedades_do_app(caso["pacote"], serial)
        minima = caso["versao_minima"]
        atual = resultado["props"].get("versionName")
        if minima and not (atual and versao_ok(atual, minima)):
            resultado.update(status="FAIL", obs=f"versão {atual} abaixo da mínima {minima}")
        else:
            resultado["status"] = "PASS"
    except Exception as erro:
        resultado.update(status="ERROR", obs=str(erro))

    if serial and resultado["status"] in {"FAIL", "ERROR"}:
        try:
            log_path = Path(pasta_prints) / nome_logcat(f"{caso['id']}_{serial}")
            resultado["logcat"] = str(coletar_logcat(log_path, serial))
        except Exception as log_error:
            resultado["obs"] += f" | Logcat capture failed: {log_error}"
    return resultado


def _executar_no_dispositivo(casos, serial, args):
    pasta_prints = Path(args.prints) / serial if args.all_devices else Path(args.prints)
    driver = criar_driver(serial) if args.appium else None
    try:
        resultados = []
        for caso in casos:
            resultado = executar_caso(caso, pasta_prints, serial, driver)
            print(f"[{resultado['status']:5}] {serial} {resultado['id']} {resultado['pacote']} {resultado['obs']}")
            resultados.append(resultado)
    finally:
        if driver is not None:
            driver.quit()

    if args.all_devices:
        base = Path(args.saida)
        safe_serial = re.sub(r"[^A-Za-z0-9_.-]+", "_", serial)
        saida = base.with_name(f"{base.stem}_{safe_serial}{base.suffix or '.xlsx'}")
    else:
        saida = Path(args.saida)
    salvar_resultados(saida, resultados)
    return sum(1 for item in resultados if item["status"] != "PASS"), saida


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run Excel-driven Android E2E checks (ADB/Appium).")
    parser.add_argument("casos", nargs="?", help=".xlsx test case workbook")
    parser.add_argument("--saida", default="resultados.xlsx")
    parser.add_argument("--prints", default="prints")
    parser.add_argument("--serial", help="Exact ADB serial / UDID")
    parser.add_argument("--appium", action="store_true", help="Use Appium for screenshots")
    parser.add_argument("--all-devices", action="store_true", help="Run sequentially on every online device")
    parser.add_argument("--gerar-modelo", metavar="ARQUIVO", help="Create a sample workbook")
    args = parser.parse_args(argv)

    if args.gerar_modelo:
        gerar_modelo(args.gerar_modelo)
        print(f"Modelo criado em {args.gerar_modelo}")
        return 0
    if not args.casos:
        parser.error("informe a planilha de casos (ou use --gerar-modelo)")
    if args.serial and args.all_devices:
        parser.error("use --serial ou --all-devices, não ambos")

    try:
        casos = ler_casos(args.casos)
        if not casos:
            parser.error("a planilha não contém casos na aba 'Casos'")
        if args.all_devices:
            devices = [item for item in d.listar_dispositivos() if item.online]
            serials = [item.serial for item in devices]
            if not serials:
                raise d.AdbError("No online Android devices found.")
        else:
            serials = [d.selecionar_dispositivo(args.serial or os.getenv("ANDROID_UDID") or None)]

        total_failures = 0
        for serial in serials:
            failures, output = _executar_no_dispositivo(casos, serial, args)
            total_failures += failures
            print(f"{len(casos)} casos em {serial}: {failures} sem PASS. Resultado: {output}")
        return 1 if total_failures else 0
    except (d.AdbError, OSError, ValueError) as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
