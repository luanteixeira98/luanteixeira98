"""Valida configurações de operadora (exemplo genérico, em JSON).

As regras ficam na lista REGRAS: cada regra é uma função que recebe um
registro (dict) e devolve uma mensagem de erro ou None. Para criar uma
regra nova, é só escrever outra função e colocá-la na lista.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

CAMPOS_OBRIGATORIOS = ("plmn", "nome", "volte", "vowifi", "vonr")
CAMPOS_BOOLEANOS = ("volte", "vowifi", "vonr")


def regra_campos_obrigatorios(r):
    faltando = [c for c in CAMPOS_OBRIGATORIOS if c not in r]
    return f"campos faltando: {', '.join(faltando)}" if faltando else None


def regra_plmn_valido(r):
    # PLMN = MCC (3 dígitos) + MNC (2 ou 3 dígitos) => 5 ou 6 dígitos
    if "plmn" in r and not re.fullmatch(r"\d{5,6}", str(r["plmn"])):
        return f"plmn inválido: {r['plmn']!r} (esperado 5 ou 6 dígitos)"


def regra_booleanos(r):
    ruins = [c for c in CAMPOS_BOOLEANOS if c in r and not isinstance(r[c], bool)]
    return f"campos que deveriam ser true/false: {', '.join(ruins)}" if ruins else None


def regra_vonr_precisa_volte(r):
    # Regra de EXEMPLO (ajuste conforme o requisito real da operadora)
    if r.get("vonr") is True and r.get("volte") is not True:
        return "vonr habilitado sem volte"


REGRAS = [regra_campos_obrigatorios, regra_plmn_valido, regra_booleanos, regra_vonr_precisa_volte]


def validar(registros):
    """Devolve {plmn_ou_indice: [erros]} só para os registros com problema."""
    problemas = {}
    for i, reg in enumerate(registros):
        erros = [msg for regra in REGRAS if (msg := regra(reg))]
        if erros:
            problemas[str(reg.get("plmn", f"registro #{i}"))] = erros
    return problemas


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        print("uso: python -m carrier_validator.validator arquivo.json")
        return 2
    registros = json.loads(Path(argv[0]).read_text(encoding="utf-8"))
    problemas = validar(registros)
    for chave, erros in problemas.items():
        print(f"❌ {chave}")
        for e in erros:
            print(f"   - {e}")
    print(f"\n{len(registros)} registros, {len(problemas)} com problema")
    return 1 if problemas else 0


if __name__ == "__main__":
    sys.exit(main())
