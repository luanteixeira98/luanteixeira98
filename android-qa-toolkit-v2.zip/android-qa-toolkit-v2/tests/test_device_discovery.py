import pytest

from android_e2e import device


def test_parse_devices_includes_online_offline_and_unauthorized():
    output = """List of devices attached
ABC123 device product:demo model:Pixel_8 device:shiba transport_id:1
emulator-5554 offline
XYZ999 unauthorized usb:1-2
"""
    parsed = device.parse_devices_output(output)
    assert [(item.serial, item.state) for item in parsed] == [
        ("ABC123", "device"), ("emulator-5554", "offline"), ("XYZ999", "unauthorized")
    ]
    assert parsed[0].model == "Pixel_8"
    assert parsed[0].online is True
    assert parsed[1].online is False


def test_select_device_automatically_when_only_one_online(monkeypatch):
    monkeypatch.setattr(device, "listar_dispositivos", lambda: [
        device.AdbDevice("phone-1", "device"), device.AdbDevice("phone-2", "offline")
    ])
    assert device.selecionar_dispositivo() == "phone-1"


def test_select_device_refuses_to_guess_between_multiple_online(monkeypatch):
    monkeypatch.setattr(device, "listar_dispositivos", lambda: [
        device.AdbDevice("phone-1", "device"), device.AdbDevice("phone-2", "device")
    ])
    with pytest.raises(device.AdbError, match="More than one"):
        device.selecionar_dispositivo()


def test_select_device_rejects_unauthorized(monkeypatch):
    monkeypatch.setattr(device, "listar_dispositivos", lambda: [device.AdbDevice("phone-1", "unauthorized")])
    with pytest.raises(device.AdbError, match="not ready"):
        device.selecionar_dispositivo("phone-1")
