from android_e2e.logs import classificar_logcat


def test_classify_android_crash_and_anr():
    result = classificar_logcat("""I/ActivityManager: Start proc
E/AndroidRuntime: FATAL EXCEPTION: main
E/ActivityManager: ANR in com.example.app
Fatal signal 11 (SIGSEGV)
""")
    assert result["line_count"] == 4
    assert result["error_categories"]["fatal_exception"] == 1
    assert result["error_categories"]["anr"] == 1
    assert result["error_categories"]["native_crash"] == 1
    assert result["error_categories"]["android_runtime"] == 1
