from openpyxl import load_workbook

from android_e2e import device as d
from android_e2e import runner
from android_e2e.excel_io import gerar_modelo, ler_casos, salvar_resultados

DUMPSYS = """
Packages:
  Package [com.exemplo.cliente] (abc123):
    versionCode=210 minSdk=26 targetSdk=34
    versionName=2.10.1
    firstInstallTime=2024-03-01 10:00:00
    lastUpdateTime=2024-05-02 11:30:00
    installerPackageName=com.android.vending
"""


def test_parse_dumpsys():
    p = d.parse_dumpsys(DUMPSYS)
    assert p["versionName"] == "2.10.1"
    assert p["versionCode"] == "210"
    assert p["targetSdk"] == "34"
    assert p["installer"] == "com.android.vending"
    assert p["lastUpdateTime"] == "2024-05-02 11:30:00"


def test_versao_compara_como_numero_e_nao_como_texto():
    assert runner.versao_ok("2.10.0", "2.9.0")        # como texto, "2.10" < "2.9" (errado!)
    assert not runner.versao_ok("1.9.9", "2.0.0")
    assert runner.versao_ok("2.0.0-beta", "2.0.0")


def test_excel_ida_e_volta(tmp_path):
    caminho = tmp_path / "casos.xlsx"
    gerar_modelo(caminho)
    casos = ler_casos(caminho)
    assert [c["id"] for c in casos] == ["TC001", "TC002"]
    assert casos[1]["versao_minima"] == "2.0.0"

    salvar_resultados(tmp_path / "res.xlsx", [
        {"id": "TC001", "descricao": "x", "pacote": "p", "status": "PASS", "props": {"versionName": "1"},
         "print1": "a.png", "print2": None, "obs": "", "quando": "agora"}])
    ws = load_workbook(tmp_path / "res.xlsx")["Resultados"]
    assert ws["D2"].value == "PASS" and ws["E2"].value == "1"


def _falsos(monkeypatch, instalado=True, versao="2.10.1"):
    monkeypatch.setattr(d, "pacote_instalado", lambda p, serial=None: instalado)
    monkeypatch.setattr(d, "abrir_info_do_app", lambda p, serial=None: None)
    monkeypatch.setattr(d, "rolar_para_baixo", lambda serial=None: None)
    monkeypatch.setattr(d, "screenshot_adb", lambda destino, serial=None: None)
    monkeypatch.setattr(d, "propriedades_do_app", lambda p, serial=None: {"versionName": versao})
    monkeypatch.setattr(runner, "esperar_tela_configuracoes", lambda driver, tempo=6: None)
    monkeypatch.setattr(runner.time, "sleep", lambda s: None)


CASO = {"id": "TC9", "descricao": "", "pacote": "com.x", "rotulo": None, "versao_minima": "2.0.0"}


def test_pass(monkeypatch, tmp_path):
    _falsos(monkeypatch)
    assert runner.executar_caso(CASO, tmp_path)["status"] == "PASS"


def test_fail_app_nao_instalado(monkeypatch, tmp_path):
    _falsos(monkeypatch, instalado=False)
    r = runner.executar_caso(CASO, tmp_path)
    assert r["status"] == "FAIL" and "não está instalado" in r["obs"]


def test_fail_versao_baixa(monkeypatch, tmp_path):
    _falsos(monkeypatch, versao="1.0.0")
    assert runner.executar_caso(CASO, tmp_path)["status"] == "FAIL"


def test_error_nao_derruba_a_execucao(monkeypatch, tmp_path):
    _falsos(monkeypatch)
    def quebra(p, serial=None):
        raise d.AdbError("aparelho offline")
    monkeypatch.setattr(d, "pacote_instalado", quebra)
    r = runner.executar_caso(CASO, tmp_path)
    assert r["status"] == "ERROR" and "offline" in r["obs"]
