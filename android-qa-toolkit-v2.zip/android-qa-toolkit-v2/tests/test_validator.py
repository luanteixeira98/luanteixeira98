import json
from pathlib import Path

from carrier_validator.validator import validar


def test_registro_valido_nao_gera_erro():
    ok = {"plmn": "72411", "nome": "X", "volte": True, "vowifi": False, "vonr": False}
    assert validar([ok]) == {}


def test_amostra_tem_tres_operadoras_com_problema():
    dados = json.loads(Path("carrier_validator/sample_configs.json").read_text(encoding="utf-8"))
    problemas = validar(dados)
    assert set(problemas) == {"7240", "72405", "72406"}
