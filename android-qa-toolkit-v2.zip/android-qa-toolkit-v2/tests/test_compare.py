import zipfile

from bootanim_compare.compare import compare, iguais, render_markdown


def _zip(caminho, frames_part0, fps=30):
    with zipfile.ZipFile(caminho, "w") as z:
        z.writestr("desc.txt", f"1080 2400 {fps}\np 1 0 part0\n")
        for nome, conteudo in frames_part0.items():
            z.writestr(f"part0/{nome}", conteudo)
    return str(caminho)


def test_zips_identicos(tmp_path):
    a = _zip(tmp_path / "a.zip", {"0001.png": b"x"})
    b = _zip(tmp_path / "b.zip", {"0001.png": b"x"})
    assert iguais(compare(a, b))


def test_detecta_frame_alterado_adicionado_e_fps(tmp_path):
    a = _zip(tmp_path / "a.zip", {"0001.png": b"x", "0002.png": b"y"})
    b = _zip(tmp_path / "b.zip", {"0001.png": b"MUDOU", "0003.png": b"z"}, fps=60)
    r = compare(a, b)
    assert r["alterados"] == ["desc.txt", "part0/0001.png"]   # desc.txt também muda (fps)
    assert r["adicionados"] == ["part0/0003.png"]
    assert r["removidos"] == ["part0/0002.png"]
    assert r["meta"] == {"fps": (30, 60)}
    assert "DIFERENÇAS" in render_markdown(r)
