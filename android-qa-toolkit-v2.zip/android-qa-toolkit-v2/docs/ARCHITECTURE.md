# Architecture overview

```text
CLI / pytest / Excel E2E runner
              |
              v
     Device selection layer
              |
       ADB device inventory
              |
      +-------+--------+
      |                |
      v                v
   Appium           ADB tools
 UiAutomator2       - getprop / dumpsys
      |             - screenshots
      v             - input / intents
 Android UI         - Logcat
      |                |
      +-------+--------+
              |
              v
   Test evidence and reports
   - pytest HTML + screenshots
   - Logcat capture + classifications
   - Excel results + evidence links

Independent utilities:
- carrier_validator: JSON configuration rules
- bootanim_compare: bootanimation ZIP comparison + GUI
```

## Design decisions

- **Explicit device identity:** every remote command/session receives a serial when a target is selected. Multiple online devices cause an explicit selection error rather than an implicit first-device choice.
- **Keep ADB and UI automation separate:** ADB is used for inventory, device properties, app metadata, shell operations, and Logcat. Appium is used for application UI sessions and screenshots.
- **No OEM dependency:** the core uses Android platform interfaces (`adb`, Android intents, UiAutomator2) rather than manufacturer SDKs.
- **Evidence on failure:** Appium tests attempt to attach a screenshot and Logcat excerpt to pytest-html when a test fails.
- **Sequential device matrix:** the current runner tests each online device one at a time. Parallel execution is intentionally deferred until per-device Appium system ports and resource isolation are configured.
