# Android device support

The toolkit is manufacturer-neutral: it uses ADB serials and the Appium UiAutomator2 driver rather than brand-specific SDKs. It is intended for physical Android phones/tablets and Android emulators on Windows, macOS, and Linux hosts.

## What is and is not guaranteed

- The exact Android OS floor depends on the installed UiAutomator2 driver version. This repository's recommended setup pins UiAutomator2 `5.0.7` with Appium 3 to retain the driver's older Android compatibility range.
- UiAutomator2 documentation lists Android 5 / API 21 as the lower bound for driver versions 2.0.0 through 5.0.7, with partial support caveats and Android 6+ recommended. Newer driver 6+ requires Android 8 / API 26 or later.
- ADB must show the device in the `device` state. `offline` and `unauthorized` devices are reported but are not selected for test sessions.
- ADB must be authorized on the device. Wireless debugging is supported when the device is paired/connected and visible to ADB.
- OEM software, restricted work profiles, custom permission dialogs, and non-standard UI accessibility trees can require test-specific handling. No single automation framework can guarantee identical behavior for every ROM or app.

## Safe device selection

- One online device: selected automatically.
- Multiple online devices: the toolkit refuses to guess; pass the exact serial via `--serial` or `--android-udid`.
- Explicit serial in `offline` or `unauthorized` state: execution stops with an actionable message.

## Verify compatibility

```bash
adb devices -l
python -m android_e2e.device
appium driver doctor uiautomator2
```

Run the Appium session smoke test against each attached device:

```bash
python scripts/run_device_matrix.py
```

The matrix runner executes devices sequentially, not in parallel, to avoid Appium UiAutomator2 system-port collisions. Parallel execution can be added later with dedicated per-device ports.
