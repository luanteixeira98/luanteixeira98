"""Interface gráfica simples (CustomTkinter). Rode com:
    python -m bootanim_compare.gui
"""
import customtkinter as ctk
from tkinter import filedialog

from .compare import compare, render_markdown


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Comparador de bootanimation.zip")
        self.geometry("720x520")
        self.source = ctk.StringVar()
        self.target = ctk.StringVar()

        for rotulo, var in (("Source", self.source), ("Target", self.target)):
            linha = ctk.CTkFrame(self)
            linha.pack(fill="x", padx=12, pady=6)
            ctk.CTkLabel(linha, text=rotulo, width=60).pack(side="left")
            ctk.CTkEntry(linha, textvariable=var).pack(side="left", fill="x", expand=True, padx=6)
            ctk.CTkButton(linha, text="Abrir", width=70,
                          command=lambda v=var: self.escolher(v)).pack(side="left")

        ctk.CTkButton(self, text="Comparar", command=self.comparar).pack(pady=8)
        self.saida = ctk.CTkTextbox(self)
        self.saida.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    def escolher(self, var):
        caminho = filedialog.askopenfilename(filetypes=[("ZIP", "*.zip")])
        if caminho:
            var.set(caminho)

    def comparar(self):
        self.saida.delete("1.0", "end")
        try:
            r = compare(self.source.get(), self.target.get())
            self.saida.insert("end", render_markdown(r))
        except Exception as erro:  # mostra o erro na tela em vez de fechar o app
            self.saida.insert("end", f"Erro: {erro}")


if __name__ == "__main__":
    App().mainloop()
