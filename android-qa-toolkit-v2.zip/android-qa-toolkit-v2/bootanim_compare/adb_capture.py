"""Captura de tela e gravação de vídeo de um aparelho Android via ADB."""
from __future__ import annotations

import shutil
import subprocess


def adb_disponivel():
    """True se o comando `adb` está instalado e no PATH."""
    return shutil.which("adb") is not None


def _adb(args, serial=None):
    cmd = ["adb"] + (["-s", serial] if serial else []) + args
    return subprocess.run(cmd, capture_output=True, check=True)


def screenshot(destino, serial=None):
    """Tira um print da tela e salva em `destino` (.png)."""
    dados = _adb(["exec-out", "screencap", "-p"], serial).stdout
    with open(destino, "wb") as f:
        f.write(dados)


def gravar_tela(destino, segundos=10, serial=None):
    """Grava a tela por `segundos` (máx. 180 no Android) e baixa o .mp4."""
    remoto = "/sdcard/gravacao_tmp.mp4"
    _adb(["shell", "screenrecord", "--time-limit", str(segundos), remoto], serial)
    _adb(["pull", remoto, destino], serial)
    _adb(["shell", "rm", remoto], serial)
