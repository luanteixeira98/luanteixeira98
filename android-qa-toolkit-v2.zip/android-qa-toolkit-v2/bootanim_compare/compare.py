"""Compara dois arquivos bootanimation.zip (build Source x build Target).

Formato do zip (padrão Android):
  desc.txt          -> 1ª linha: "LARGURA ALTURA FPS"; demais: "p REPETICOES PAUSA PASTA"
  part0/0001.png    -> frames de cada parte da animação
  part1/...
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import zipfile
from pathlib import Path


def hash_entries(zip_path):
    """Devolve {nome_do_arquivo: sha256} de tudo que existe dentro do zip.

    O hash é uma "impressão digital" do conteúdo: se dois arquivos têm o mesmo
    nome mas hashes diferentes, o conteúdo mudou.
    """
    resultado = {}
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            resultado[info.filename] = hashlib.sha256(z.read(info)).hexdigest()
    return resultado


def parse_desc(zip_path):
    """Lê o desc.txt e devolve resolução, fps e a lista de partes."""
    with zipfile.ZipFile(zip_path) as z:
        texto = z.read("desc.txt").decode("utf-8", errors="replace")
    linhas = [l.strip() for l in texto.splitlines() if l.strip()]
    largura, altura, fps = (int(x) for x in linhas[0].split()[:3])
    partes = []
    for linha in linhas[1:]:
        campos = linha.split()
        if campos[0] in ("p", "c") and len(campos) >= 4:
            partes.append({
                "tipo": campos[0],
                "repeticoes": int(campos[1]),
                "pausa": int(campos[2]),
                "pasta": campos[3],
            })
    return {"largura": largura, "altura": altura, "fps": fps, "partes": partes}


def frames_por_parte(hashes, partes):
    """Conta quantos frames existem em cada pasta de parte."""
    contagem = {}
    for p in partes:
        prefixo = p["pasta"].rstrip("/") + "/"
        contagem[p["pasta"]] = sum(1 for nome in hashes if nome.startswith(prefixo))
    return contagem


def compare(source, target):
    """Compara os dois zips e devolve um dicionário com tudo que mudou."""
    h_src, h_tgt = hash_entries(source), hash_entries(target)
    d_src, d_tgt = parse_desc(source), parse_desc(target)

    meta = {
        k: (d_src[k], d_tgt[k])
        for k in ("largura", "altura", "fps")
        if d_src[k] != d_tgt[k]
    }
    return {
        "meta": meta,
        "partes_mudaram": d_src["partes"] != d_tgt["partes"],
        "frames_source": frames_por_parte(h_src, d_src["partes"]),
        "frames_target": frames_por_parte(h_tgt, d_tgt["partes"]),
        "adicionados": sorted(set(h_tgt) - set(h_src)),   # só existem no Target
        "removidos": sorted(set(h_src) - set(h_tgt)),     # só existiam no Source
        "alterados": sorted(                              # mesmo nome, conteúdo diferente
            n for n in set(h_src) & set(h_tgt) if h_src[n] != h_tgt[n]
        ),
    }


def iguais(resultado):
    return not (
        resultado["meta"] or resultado["partes_mudaram"] or resultado["adicionados"]
        or resultado["removidos"] or resultado["alterados"]
    )


def render_markdown(resultado, nome_source="Source", nome_target="Target"):
    """Transforma o resultado em um relatório de validação em Markdown."""
    L = [f"# Relatório: {nome_source} x {nome_target}", ""]
    L.append("**Resultado:** " + ("IGUAIS ✅" if iguais(resultado) else "DIFERENÇAS ENCONTRADAS ⚠️"))
    L.append("")
    if resultado["meta"]:
        L.append("## Metadados (desc.txt)")
        for campo, (a, b) in resultado["meta"].items():
            L.append(f"- {campo}: {a} → {b}")
        L.append("")
    if resultado["partes_mudaram"]:
        L.append("## Estrutura das partes mudou (repetições, pausa ou pastas)\n")
    L.append("## Frames por parte")
    for pasta in sorted(set(resultado["frames_source"]) | set(resultado["frames_target"])):
        a = resultado["frames_source"].get(pasta, 0)
        b = resultado["frames_target"].get(pasta, 0)
        marca = "" if a == b else "  ← diferente"
        L.append(f"- {pasta}: {a} → {b}{marca}")
    for titulo, chave in (("Adicionados", "adicionados"), ("Removidos", "removidos"), ("Alterados", "alterados")):
        itens = resultado[chave]
        if itens:
            L += ["", f"## {titulo} ({len(itens)})"] + [f"- {n}" for n in itens]
    return "\n".join(L) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description="Compara dois bootanimation.zip")
    ap.add_argument("source")
    ap.add_argument("target")
    ap.add_argument("-o", "--saida", help="salva o relatório .md neste caminho")
    args = ap.parse_args(argv)

    resultado = compare(args.source, args.target)
    relatorio = render_markdown(resultado, Path(args.source).name, Path(args.target).name)
    if args.saida:
        Path(args.saida).write_text(relatorio, encoding="utf-8")
    print(relatorio)
    return 0 if iguais(resultado) else 1   # código de saída útil pra CI/CD


if __name__ == "__main__":
    sys.exit(main())
