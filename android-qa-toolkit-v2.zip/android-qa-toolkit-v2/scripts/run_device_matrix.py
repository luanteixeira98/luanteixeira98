"""Run Appium tests sequentially on every online ADB device."""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

from android_e2e.device import AdbError, listar_dispositivos


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run the Appium test suite on each online Android device.")
    parser.add_argument("--tests", default="appium_tests", help="Pytest path (default: appium_tests)")
    parser.add_argument("--reports", default="reports/device-matrix")
    args, pytest_args = parser.parse_known_args(argv)
    devices = [device for device in listar_dispositivos() if device.online]
    if not devices:
        raise SystemExit("No online Android devices found. Check `adb devices -l`.")

    report_dir = Path(args.reports)
    report_dir.mkdir(parents=True, exist_ok=True)
    failures = 0
    for device in devices:
        print(f"\n=== Running tests on {device.serial} ({device.model or 'Android device'}) ===")
        safe_serial = re.sub(r"[^A-Za-z0-9_.-]+", "_", device.serial)
        report_file = report_dir / f"report_{safe_serial}.html"
        command = [
            sys.executable, "-m", "pytest", args.tests, "-m", "appium", "-v",
            "--android-udid", device.serial,
            "--html", str(report_file), "--self-contained-html",
            *pytest_args,
        ]
        result = subprocess.run(command, check=False)
        if result.returncode != 0:
            failures += 1
    print(f"\nDevice matrix complete: {len(devices)} devices, {failures} runs with failures.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
