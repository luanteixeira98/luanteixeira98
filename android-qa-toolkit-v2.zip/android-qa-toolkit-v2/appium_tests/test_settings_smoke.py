"""Manufacturer-neutral Appium session smoke checks."""
import os

import pytest


@pytest.mark.appium
def test_android_device_session_is_responsive(driver, android_serial):
    """A successful session and a non-zero display prove basic device control."""
    size = driver.get_window_size()
    assert size["width"] > 0
    assert size["height"] > 0
    assert driver.session_id
    assert driver.capabilities.get("platformName", "").lower() == "android"
    assert android_serial


@pytest.mark.appium
def test_configured_app_can_be_launched(driver):
    """Optional app-specific smoke test, enabled by APP_PACKAGE in .env."""
    package = os.getenv("APP_PACKAGE")
    if not package:
        pytest.skip("Set APP_PACKAGE in .env to enable the app launch smoke test.")
    driver.activate_app(package)
    assert driver.current_package == package
