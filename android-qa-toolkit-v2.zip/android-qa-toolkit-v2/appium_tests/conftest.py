"""Appium fixtures, explicit device selection, and failure evidence."""
from __future__ import annotations

import base64
import os
import re
from datetime import datetime, timezone
from pathlib import Path

import pytest

from android_e2e.appium import criar_driver, verificar_servidor_appium, appium_server_url
from android_e2e.device import AdbError, selecionar_dispositivo
from android_e2e.logs import coletar_logcat


def pytest_addoption(parser):
    group = parser.getgroup("android-qa")
    group.addoption("--android-udid", action="store", default=None,
                    help="Exact ADB serial to use; required when multiple devices are online.")
    group.addoption("--appium-url", action="store", default=None,
                    help="Appium server URL (default: APPIUM_SERVER_URL or localhost:4723).")


@pytest.fixture(scope="session")
def android_serial(request):
    requested = request.config.getoption("--android-udid") or os.getenv("ANDROID_UDID") or None
    try:
        return selecionar_dispositivo(requested)
    except AdbError as exc:
        pytest.skip(str(exc))


@pytest.fixture
def driver(request, android_serial):
    url = request.config.getoption("--appium-url") or appium_server_url()
    if not verificar_servidor_appium(url):
        pytest.skip(f"Appium server is not reachable at {url}. Start it with `appium`.")
    session = criar_driver(android_serial, server_url=url)
    try:
        yield session
    finally:
        session.quit()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when != "call" or not report.failed:
        return

    driver_obj = item.funcargs.get("driver")
    serial = item.funcargs.get("android_serial")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", item.name)
    artifact_dir = Path("reports") / "artifacts"
    artifact_dir.mkdir(parents=True, exist_ok=True)
    extras = getattr(report, "extras", [])

    screenshot = None
    if driver_obj is not None:
        screenshot = artifact_dir / f"{safe_name}_{stamp}.png"
        try:
            driver_obj.get_screenshot_as_file(str(screenshot))
        except Exception:
            screenshot = None

    log_path = None
    if serial:
        try:
            log_path = coletar_logcat(artifact_dir / f"{safe_name}_{stamp}_logcat.txt", serial)
        except Exception as exc:
            report.sections.append(("Logcat capture", str(exc)))

    try:
        import pytest_html
        if screenshot and screenshot.exists():
            image_data = base64.b64encode(screenshot.read_bytes()).decode("ascii")
            extras.append(pytest_html.extras.png(image_data, name="Failure screenshot"))
        if log_path and log_path.exists():
            tail = log_path.read_text(encoding="utf-8", errors="replace")[-12000:]
            extras.append(pytest_html.extras.text(tail, name="Logcat tail"))
            extras.append(pytest_html.extras.url(str(log_path), name="Full Logcat"))
    except ImportError:
        pass
    report.extras = extras
