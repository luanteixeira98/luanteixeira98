import argparse

from android_qa.config import settings
from android_qa.logcat import save_logcat


def main():
    parser = argparse.ArgumentParser(description="Collect Android Logcat output.")
    parser.add_argument("--serial", default=settings.android_udid)
    parser.add_argument("--buffer", default=settings.logcat_buffer)
    args = parser.parse_args()
    print(f"Logcat saved to: {save_logcat(serial=args.serial, buffer=args.buffer)}")


if __name__ == "__main__":
    main()
