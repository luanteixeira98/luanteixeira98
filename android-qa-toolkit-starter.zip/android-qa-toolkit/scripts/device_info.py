from pprint import pprint

from android_qa.adb_manager import AdbManager


def main():
    adb = AdbManager()
    devices = adb.list_devices()
    if not devices:
        print("No Android devices found. Check USB debugging and run: adb devices")
        return

    for device in devices:
        print(f"\\nDevice: {device.serial} ({device.state})")
        if device.state == "device":
            pprint(adb.get_device_summary(device.serial))


if __name__ == "__main__":
    main()
