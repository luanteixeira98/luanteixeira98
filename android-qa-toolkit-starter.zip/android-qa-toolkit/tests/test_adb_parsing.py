from android_qa.adb_manager import AdbManager


def test_list_devices_parses_serial_and_state(monkeypatch):
    manager = AdbManager()
    monkeypatch.setattr(
        manager, "run",
        lambda *args: "List of devices attached\nABC123\tdevice\nemulator-5554\toffline\n"
    )
    devices = manager.list_devices()
    assert [(device.serial, device.state) for device in devices] == [
        ("ABC123", "device"),
        ("emulator-5554", "offline"),
    ]
