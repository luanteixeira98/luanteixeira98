from android_qa.config import Settings


def test_settings_has_default_appium_url():
    config = Settings()
    assert config.appium_server_url == "http://127.0.0.1:4723"
