import pytest
from android_qa.appium_driver import create_android_driver


@pytest.fixture
def driver():
    session = create_android_driver()
    try:
        yield session
    finally:
        session.quit()
