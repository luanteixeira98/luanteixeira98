import pytest
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


@pytest.mark.appium
def test_android_settings_can_be_opened(driver):
    """Smoke test: launch Android Settings and wait for its package activity."""
    driver.activate_app("com.android.settings")
    WebDriverWait(driver, 15).until(
        EC.presence_of_element_located(
            (AppiumBy.XPATH, "//*[contains(@package, 'settings')]")
        )
    )
