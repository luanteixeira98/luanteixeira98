from datetime import datetime, timezone
from pathlib import Path

from android_qa.adb_manager import AdbManager


def save_logcat(output_dir: str = "reports", serial: str | None = None,
                buffer: str = "main") -> Path:
    """Save the selected Logcat buffer to a timestamped text file."""
    adb = AdbManager(timeout=30)
    args = ["-s", serial] if serial else []
    content = adb.run(*args, "logcat", "-d", "-b", buffer, "-v", "threadtime")
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = target / f"logcat_{timestamp}.txt"
    path.write_text(content + "\n", encoding="utf-8")
    return path
