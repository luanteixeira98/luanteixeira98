from appium import webdriver
from appium.options.android import UiAutomator2Options

from android_qa.config import settings


def create_android_driver():
    """Create an Appium Android session using local environment settings."""
    options = UiAutomator2Options()
    options.platform_name = "Android"
    options.automation_name = "UiAutomator2"
    options.device_name = "Android"
    options.new_command_timeout = 120

    if settings.android_udid:
        options.udid = settings.android_udid
    if settings.android_platform_version:
        options.platform_version = settings.android_platform_version
    if settings.app_package:
        options.app_package = settings.app_package
    if settings.app_activity:
        options.app_activity = settings.app_activity

    return webdriver.Remote(settings.appium_server_url, options=options)
