from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    appium_server_url: str = os.getenv("APPIUM_SERVER_URL", "http://127.0.0.1:4723")
    android_udid: str | None = os.getenv("ANDROID_UDID") or None
    android_platform_version: str | None = os.getenv("ANDROID_PLATFORM_VERSION") or None
    app_package: str | None = os.getenv("APP_PACKAGE") or None
    app_activity: str | None = os.getenv("APP_ACTIVITY") or None
    logcat_buffer: str = os.getenv("LOGCAT_BUFFER", "main")


settings = Settings()
