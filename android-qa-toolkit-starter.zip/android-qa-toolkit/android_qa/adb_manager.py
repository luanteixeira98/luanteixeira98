import subprocess
from dataclasses import dataclass


class AdbError(RuntimeError):
    """Raised when an ADB command fails."""


@dataclass(frozen=True)
class AndroidDevice:
    serial: str
    state: str


class AdbManager:
    def __init__(self, adb_path: str = "adb", timeout: int = 15):
        self.adb_path = adb_path
        self.timeout = timeout

    def run(self, *args: str) -> str:
        command = [self.adb_path, *args]
        try:
            result = subprocess.run(
                command, capture_output=True, text=True,
                timeout=self.timeout, check=False
            )
        except FileNotFoundError as exc:
            raise AdbError("ADB not found. Install Android Platform-Tools and add adb to PATH.") from exc
        except subprocess.TimeoutExpired as exc:
            raise AdbError(f"ADB command timed out: {' '.join(command)}") from exc

        if result.returncode != 0:
            message = result.stderr.strip() or result.stdout.strip()
            raise AdbError(f"ADB command failed ({result.returncode}): {message}")
        return result.stdout.strip()

    def list_devices(self) -> list[AndroidDevice]:
        output = self.run("devices")
        devices = []
        for line in output.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 2:
                devices.append(AndroidDevice(parts[0], parts[1]))
        return devices

    def get_device_summary(self, serial: str) -> dict[str, str]:
        def prop(name: str) -> str:
            return self.run("-s", serial, "shell", "getprop", name)
        return {
            "manufacturer": prop("ro.product.manufacturer"),
            "model": prop("ro.product.model"),
            "android_version": prop("ro.build.version.release"),
            "build_id": prop("ro.build.id"),
            "sdk": prop("ro.build.version.sdk"),
        }
